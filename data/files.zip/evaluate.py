"""
Evaluation: concept-level P/R/F1, hybrid union, McNemar significance,
and a per-error-type breakdown for the paper's figure.

Reads:  data/norm_gold.jsonl, data/norm_lexicon.jsonl, data/norm_llm.jsonl
Writes: results/main_table.csv        -> Table 2
        results/errors.csv            -> for Figure 2 + manual error typing
        results/summary.json
Prints  a LaTeX-ready table you can paste into the IS template.
"""
import json, os, csv
from itertools import combinations

os.makedirs("results", exist_ok=True)


def load(path):
    return {json.loads(l)["id"]: set(json.loads(l)["skills"])
            for l in open(path, encoding="utf-8")}


def prf(gold, pred):
    tp = fp = fn = 0
    for aid, g in gold.items():
        p = pred.get(aid, set())
        tp += len(g & p); fp += len(p - g); fn += len(g - p)
    P = tp / (tp + fp) if tp + fp else 0.0
    R = tp / (tp + fn) if tp + fn else 0.0
    F = 2 * P * R / (P + R) if P + R else 0.0
    return dict(TP=tp, FP=fp, FN=fn, P=round(P, 3), R=round(R, 3), F1=round(F, 3))


def mcnemar(gold, a, b):
    """Paired test over (ad, gold-concept) instances: did each system find it?"""
    only_a = only_b = 0
    for aid, g in gold.items():
        pa, pb = a.get(aid, set()), b.get(aid, set())
        for concept in g:
            ha, hb = concept in pa, concept in pb
            if ha and not hb: only_a += 1
            elif hb and not ha: only_b += 1
    n = only_a + only_b
    if n == 0:
        return dict(b=only_a, c=only_b, stat=0.0, p=1.0)
    # continuity-corrected chi-square, 1 dof
    stat = (abs(only_a - only_b) - 1) ** 2 / n
    try:
        from scipy.stats import chi2
        p = float(1 - chi2.cdf(stat, 1))
    except ImportError:
        p = None      # pip install scipy for exact p-values
    return dict(b=only_a, c=only_b, stat=round(stat, 3),
                p=(round(p, 5) if p is not None else "install scipy"))


def main():
    gold = load("data/norm_gold.jsonl")
    systems = {"Lexicon (ESCO)": load("data/norm_lexicon.jsonl")}
    if os.path.exists("data/norm_llm.jsonl"):
        systems["LLM (zero-shot)"] = load("data/norm_llm.jsonl")
        systems["Union (hybrid)"] = {
            aid: systems["Lexicon (ESCO)"].get(aid, set()) | systems["LLM (zero-shot)"].get(aid, set())
            for aid in gold
        }

    print(f"Ads evaluated: {len(gold)}")
    print(f"Gold concepts: {sum(len(v) for v in gold.values())}")
    print(f"Mean gold skills/ad: {sum(len(v) for v in gold.values()) / max(len(gold), 1):.1f}\n")

    rows = []
    for name, preds in systems.items():
        r = prf(gold, preds)
        r["System"] = name
        rows.append(r)
        print(f"{name:20s}  P={r['P']:.3f}  R={r['R']:.3f}  F1={r['F1']:.3f}"
              f"   (TP={r['TP']} FP={r['FP']} FN={r['FN']})")

    with open("results/main_table.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["System", "P", "R", "F1", "TP", "FP", "FN"])
        w.writeheader()
        for r in rows:
            w.writerow({k: r[k] for k in w.fieldnames})

    print("\n--- McNemar tests ---")
    tests = {}
    for a, b in combinations(systems, 2):
        t = mcnemar(gold, systems[a], systems[b])
        tests[f"{a} vs {b}"] = t
        print(f"{a} vs {b}: only-first={t['b']} only-second={t['c']} "
              f"chi2={t['stat']} p={t['p']}")

    # ---- error dump for manual typing (Figure 2) ----
    with open("results/errors.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["ad_id", "system", "error_type", "concept", "manual_category"])
        for name, preds in systems.items():
            if name.startswith("Union"):
                continue
            for aid, g in gold.items():
                p = preds.get(aid, set())
                for c in sorted(p - g):
                    w.writerow([aid, name, "false_positive", c, ""])
                for c in sorted(g - p):
                    w.writerow([aid, name, "false_negative", c, ""])
    print("\nwrote results/errors.csv — sample ~30 rows per system and fill "
          "'manual_category' for Figure 2")

    json.dump({"n_ads": len(gold), "results": rows, "mcnemar": tests},
              open("results/summary.json", "w"), indent=2)

    # ---- LaTeX for the paper ----
    print("\n--- paste into the IS template ---")
    print(r"\begin{tabular}{lccc}")
    print(r"\hline System & P & R & F1 \\ \hline")
    for r in rows:
        print(f"{r['System']} & {r['P']:.3f} & {r['R']:.3f} & {r['F1']:.3f} " + r"\\")
    print(r"\hline")
    print(r"\end{tabular}")


if __name__ == "__main__":
    main()
