"""
LLM-based skill extraction from job advertisements.

Reads:  data/gold.jsonl          (to know which ads to process)
        data/sample_120.jsonl    (the ad texts)
Writes: data/preds_llm.jsonl     (raw LLM output, before normalisation)
        data/llm_run_log.json    (cost, latency, parse failures -> Table 3)

Usage:
    python llm_extract.py

Requires OPENAI_API_KEY in .env  (works with OpenAI, or any OpenAI-compatible
endpoint such as Ollama/LM Studio via OPENAI_BASE_URL).
"""
import json, os, re, time, sys
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------- config ----
MODEL       = os.environ.get("LLM_MODEL", "gpt-4o-mini")
BASE_URL    = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1")
API_KEY     = os.environ.get("OPENAI_API_KEY", "")
MAX_CHARS   = 6000          # truncate very long ads
SLEEP       = 0.5           # politeness between calls

# price per 1M tokens (USD) — update to match your model, used for Table 3
PRICE_IN    = float(os.environ.get("LLM_PRICE_IN",  "0.15"))
PRICE_OUT   = float(os.environ.get("LLM_PRICE_OUT", "0.60"))

# ---------------------------------------------------------------- prompt ----
# NOTE: this exact string goes into the paper as Figure 2. Do not reword it
# after the run without re-running, or the paper will not match the code.
PROMPT = """You are extracting skills from a job advertisement.

List every skill, tool, technology, programming language, certification, or
professional competence that the advertisement states as a requirement,
preference, or responsibility of the role.

Rules:
- Only list skills the advertisement actually states. Do not infer skills.
- Do not list the job title itself.
- Ignore skills mentioned only in equal-opportunity statements, benefits
  sections, or legal disclaimers.
- Use short skill names (1-4 words), lowercase.

Return ONLY a JSON array of strings. No explanation, no markdown.

Job advertisement:
\"\"\"{text}\"\"\""""


def call_llm(text: str):
    """Returns (skills, usage_dict, raw_string). skills is None on parse failure."""
    from openai import OpenAI
    client = OpenAI(api_key=API_KEY, base_url=BASE_URL)

    resp = client.chat.completions.create(
        model=MODEL,
        messages=[{"role": "user", "content": PROMPT.format(text=text[:MAX_CHARS])}],
        temperature=0,
    )
    raw = resp.choices[0].message.content.strip()
    usage = {
        "in":  getattr(resp.usage, "prompt_tokens", 0),
        "out": getattr(resp.usage, "completion_tokens", 0),
    }
    return parse(raw), usage, raw


def parse(raw: str):
    """Robust JSON-array extraction. Returns list[str] or None."""
    s = raw.strip()
    s = re.sub(r"^```(?:json)?", "", s).strip()
    s = re.sub(r"```$", "", s).strip()
    try:
        val = json.loads(s)
    except json.JSONDecodeError:
        m = re.search(r"\[.*\]", s, re.S)          # fallback: grab first [...]
        if not m:
            return None
        try:
            val = json.loads(m.group(0))
        except json.JSONDecodeError:
            return None
    if not isinstance(val, list):
        return None
    return [str(x).strip().lower() for x in val if str(x).strip()]


def main():
    if not API_KEY:
        sys.exit("OPENAI_API_KEY missing from .env")

    ads = {json.loads(l)["id"]: json.loads(l)
           for l in open("data/sample_120.jsonl", encoding="utf-8")}

    if os.path.exists("data/gold.jsonl"):
        ids = [json.loads(l)["id"] for l in open("data/gold.jsonl", encoding="utf-8")]
        print(f"Processing {len(ids)} annotated ads from gold.jsonl")
    else:
        ids = list(ads)[:5]
        print("gold.jsonl not found — DRY RUN on 5 ads only")

    out, log = [], {"model": MODEL, "n": 0, "parse_failures": 0,
                    "retries": 0, "tokens_in": 0, "tokens_out": 0, "seconds": 0.0}

    t0 = time.time()
    for i, aid in enumerate(ids, 1):
        ad = ads.get(aid)
        if ad is None:
            print(f"  !! id {aid} not in sample_120.jsonl, skipping")
            continue

        skills, usage, raw = call_llm(ad["text"])
        if skills is None:                       # one retry, as reported in paper
            log["retries"] += 1
            time.sleep(1)
            skills, usage2, raw = call_llm(ad["text"])
            usage["in"] += usage2["in"]; usage["out"] += usage2["out"]
            if skills is None:
                log["parse_failures"] += 1
                skills = []

        out.append({"id": aid, "skills": skills, "raw": raw})
        log["tokens_in"] += usage["in"]; log["tokens_out"] += usage["out"]
        log["n"] += 1
        print(f"[{i}/{len(ids)}] {ad['title'][:45]:45s} -> {len(skills)} skills")
        time.sleep(SLEEP)

    log["seconds"] = round(time.time() - t0, 1)
    log["seconds_per_ad"] = round(log["seconds"] / max(log["n"], 1), 2)
    log["cost_usd"] = round(log["tokens_in"] / 1e6 * PRICE_IN
                            + log["tokens_out"] / 1e6 * PRICE_OUT, 4)
    log["cost_per_1000_ads"] = round(log["cost_usd"] / max(log["n"], 1) * 1000, 2)

    with open("data/preds_llm.jsonl", "w", encoding="utf-8") as f:
        for r in out:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    json.dump(log, open("data/llm_run_log.json", "w"), indent=2)

    print("\n--- run log (goes into Table 3) ---")
    print(json.dumps(log, indent=2))


if __name__ == "__main__":
    main()
