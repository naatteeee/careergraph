"""
Normalise gold annotations and both systems' outputs to a common vocabulary.

This is the fairness-critical step: the SAME function is applied to gold,
lexicon output and LLM output, so no system is advantaged by the wording it
happens to use.

Reads:  data/esco_taxonomy.json
        data/gold.jsonl
        data/preds_llm.jsonl
        data/annotation_sheet.csv   (for the lexicon predictions in column D)
Writes: data/norm_gold.jsonl
        data/norm_lexicon.jsonl
        data/norm_llm.jsonl
        data/normalisation_report.json
"""
import json, csv, re, os
from collections import Counter

TAX = json.load(open("data/esco_taxonomy.json", encoding="utf-8"))

# surface form -> canonical ESCO preferred label
FORM2SKILL = {}
for skill, v in TAX.items():
    for f in v["forms"]:
        FORM2SKILL[f] = skill
    FORM2SKILL[skill] = skill

PUNCT = re.compile(r"[^a-z0-9+#. ]+")
WS    = re.compile(r"\s+")


def simplify(s: str) -> str:
    s = s.strip().lower()
    s = PUNCT.sub(" ", s)
    return WS.sub(" ", s).strip()


SIMPLE2SKILL = {simplify(f): s for f, s in FORM2SKILL.items()}

stats = Counter()


def normalise_one(raw: str) -> str:
    """Map one raw skill string to an ESCO concept, or OOV:<phrase>."""
    s = raw.strip().lower()
    if s.startswith("oov:"):
        stats["already_oov"] += 1
        return s

    if s in FORM2SKILL:                    # stage 1: exact surface form
        stats["exact"] += 1
        return FORM2SKILL[s]

    simp = simplify(s)
    if simp in SIMPLE2SKILL:               # stage 2: simplified lookup
        stats["simplified"] += 1
        return SIMPLE2SKILL[simp]

    stats["oov"] += 1                      # stage 3: out of vocabulary
    return "oov:" + simp


def normalise_set(skills):
    return sorted({normalise_one(s) for s in skills if str(s).strip()})


def write(path, records):
    with open(path, "w", encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"wrote {path} ({len(records)} rows)")


def main():
    gold_ids = []

    # ---- gold ----
    gold = []
    for line in open("data/gold.jsonl", encoding="utf-8"):
        r = json.loads(line)
        gold_ids.append(r["id"])
        gold.append({"id": r["id"], "skills": normalise_set(r["skills"])})
    write("data/norm_gold.jsonl", gold)

    keep = set(gold_ids)

    # ---- lexicon (column D of the annotation sheet) ----
    lex = []
    with open("data/annotation_sheet.csv", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            if row["id"] not in keep:
                continue
            preds = [s for s in row["predicted_skills"].split(";") if s.strip()]
            lex.append({"id": row["id"], "skills": normalise_set(preds)})
    write("data/norm_lexicon.jsonl", lex)

    # ---- LLM ----
    llm = []
    if os.path.exists("data/preds_llm.jsonl"):
        for line in open("data/preds_llm.jsonl", encoding="utf-8"):
            r = json.loads(line)
            if r["id"] not in keep:
                continue
            llm.append({"id": r["id"], "skills": normalise_set(r["skills"])})
        write("data/norm_llm.jsonl", llm)
    else:
        print("!! data/preds_llm.jsonl missing — run llm_extract.py first")

    report = dict(stats)
    total = sum(stats.values())
    report["oov_rate"] = round(stats["oov"] / total, 3) if total else 0
    json.dump(report, open("data/normalisation_report.json", "w"), indent=2)
    print("\n--- normalisation report ---")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
